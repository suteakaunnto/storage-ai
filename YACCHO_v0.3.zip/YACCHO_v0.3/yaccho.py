# -*- coding: utf-8 -*-
import ast, operator, re, sys
from pathlib import Path

BIN={ast.Add:operator.add,ast.Sub:operator.sub,ast.Mult:operator.mul,ast.Div:operator.truediv,ast.FloorDiv:operator.floordiv,ast.Mod:operator.mod}
CMP={ast.Eq:operator.eq,ast.NotEq:operator.ne,ast.Lt:operator.lt,ast.LtE:operator.le,ast.Gt:operator.gt,ast.GtE:operator.ge,ast.In:lambda a,b:a in b,ast.NotIn:lambda a,b:a not in b}
UNARY={ast.USub:operator.neg,ast.UAdd:operator.pos,ast.Not:operator.not_}
class YacchoError(Exception): pass
class _Return(Exception):
    def __init__(self,v): self.value=v
class _Break(Exception): pass
class _Continue(Exception): pass

class Interpreter:
    def __init__(self, output=None, max_loop=100000):
        self.env={}; self.functions={}; self.output=output or print; self.max_loop=max_loop; self.line=0
    def fail(self,msg): raise YacchoError(f"{msg}（{self.line}行目）")
    def expression(self,text):
        try: return self.eval(ast.parse(text.strip(),mode="eval").body)
        except YacchoError: raise
        except Exception as e: self.fail(f"式を評価できません: {text!r} ({e})")
    def eval(self,n):
        if isinstance(n,ast.Constant) and isinstance(n.value,(str,int,float,bool,type(None))): return n.value
        if isinstance(n,ast.Name):
            if n.id=="True": return True
            if n.id=="False": return False
            if n.id=="None": return None
            if n.id in self.env: return self.env[n.id]
            self.fail(f"変数「{n.id}」はまだありません")
        if isinstance(n,(ast.List,ast.Tuple)):
            a=[self.eval(x) for x in n.elts]; return a if isinstance(n,ast.List) else tuple(a)
        if isinstance(n,ast.Dict): return {self.eval(k):self.eval(v) for k,v in zip(n.keys,n.values)}
        if isinstance(n,ast.BinOp) and type(n.op) in BIN: return BIN[type(n.op)](self.eval(n.left),self.eval(n.right))
        if isinstance(n,ast.UnaryOp) and type(n.op) in UNARY: return UNARY[type(n.op)](self.eval(n.operand))
        if isinstance(n,ast.BoolOp):
            vals=n.values
            if isinstance(n.op,ast.And):
                result=True
                for x in vals:
                    result=self.eval(x)
                    if not result:return result
                return result
            if isinstance(n.op,ast.Or):
                result=False
                for x in vals:
                    result=self.eval(x)
                    if result:return result
                return result
        if isinstance(n,ast.Compare):
            left=self.eval(n.left)
            for op,r in zip(n.ops,n.comparators):
                right=self.eval(r)
                if type(op) not in CMP:self.fail("この比較演算子は使えません")
                if not CMP[type(op)](left,right):return False
                left=right
            return True
        if isinstance(n,ast.Subscript):return self.eval(n.value)[self.eval(n.slice)]
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Name):
            if n.keywords:self.fail("キーワード引数はまだ使えません")
            name=n.func.id; a=[self.eval(x) for x in n.args]
            if name=="表示":self.output(*a);return None
            if name=="長さ":
                self.arity(name,a,1);return len(a[0])
            if name=="追加":
                self.arity(name,a,2);a[0].append(a[1]);return a[0]
            if name=="削除":
                self.arity(name,a,2)
                if isinstance(a[1],int):return a[0].pop(a[1])
                a[0].remove(a[1]);return a[0]
            if name=="範囲":
                if not 1<=len(a)<=3:self.fail("範囲()の引数は1〜3個です")
                return list(range(*a))
            if name=="型":
                self.arity(name,a,1);v=a[0]
                for typ,label in ((type(None),"なし"),(bool,"真偽値"),(int,"整数"),(float,"小数"),(str,"文字列"),(list,"リスト"),(tuple,"タプル"),(dict,"辞書")):
                    if type(v) is typ:return label
                return "不明"
            if name in self.functions:
                params,body=self.functions[name]
                if len(a)!=len(params):self.fail(f"関数「{name}」の引数の数が違います")
                old=self.env;self.env=dict(zip(params,a))
                try:
                    try:self.execute(body)
                    except _Return as r:return r.value
                    return None
                finally:self.env=old
            self.fail(f"関数「{name}」はありません")
        self.fail("この式の書き方はまだ使えません")
    def arity(self,n,a,k):
        if len(a)!=k:self.fail(f"{n}()の引数は{k}個です")
    def run_file(self,p):
        try:self.run_text(Path(p).read_text(encoding="utf-8-sig"))
        except OSError as e:raise YacchoError(f"ファイルを開けません: {e}")
    def run_text(self,s):self.execute(s.splitlines())
    def take(self,lines,start,stops):
        body=[];depth=0;i=start
        opener=re.compile(r"^(?:もし\s+.+\s+なら|関数\s+.+|\d+\s*回くりかえす|条件\s+.+\s+のあいだくりかえす|それぞれ\s+\w+\s+in\s+.+\s+くりかえす)$")
        while i<len(lines):
            s=lines[i].strip()
            if depth==0 and s in stops:return body,i+1,s
            if opener.match(s):depth+=1
            elif s=="おわり":
                if depth==0:self.line=i+1;self.fail("対応する開始命令がありません")
                depth-=1
            body.append(lines[i]);i+=1
        self.line=len(lines);self.fail("ブロックの終わり「おわり」が見つかりません")
    def execute(self,lines):
        i=0
        while i<len(lines):
            self.line=i+1;s=lines[i].strip();i+=1
            if not s or s.startswith("#"):continue
            if s=="おわり":self.fail("対応する開始命令がありません")
            if s=="ぬける":raise _Break()
            if s=="つぎへ":raise _Continue()
            if s.startswith("返す"):
                v=s[2:].strip();raise _Return(self.expression(v) if v else None)
            m=re.fullmatch(r"もし\s+(.+?)\s+なら",s)
            if m:
                yes,j,mark=self.take(lines,i,{"そうでなければ","おわり"});no=[]
                if mark=="そうでなければ":no,j,_=self.take(lines,j,{"おわり"})
                self.execute(yes if self.expression(m.group(1)) else no);i=j;continue
            m=re.fullmatch(r"(\d+)\s*回くりかえす",s)
            if m:
                body,i,_=self.take(lines,i,{"おわり"});count=int(m.group(1))
                if count>self.max_loop:self.fail("繰り返し回数の上限を超えました")
                for _ in range(count):
                    try:self.execute(body)
                    except _Continue:continue
                    except _Break:break
                continue
            m=re.fullmatch(r"条件\s+(.+?)\s+のあいだくりかえす",s)
            if m:
                body,i,_=self.take(lines,i,{"おわり"});count=0
                while self.expression(m.group(1)):
                    count+=1
                    if count>self.max_loop:self.fail("条件ループが上限を超えました")
                    try:self.execute(body)
                    except _Continue:continue
                    except _Break:break
                continue
            m=re.fullmatch(r"それぞれ\s+(\w+)\s+in\s+(.+?)\s+くりかえす",s)
            if m:
                var,exp=m.groups();body,i,_=self.take(lines,i,{"おわり"})
                for v in self.expression(exp):
                    self.env[var]=v
                    try:self.execute(body)
                    except _Continue:continue
                    except _Break:break
                continue
            m=re.fullmatch(r"関数\s+([^\s(]+)\((.*?)\)",s)
            if m:
                ps=[x.strip() for x in m.group(2).split(",") if x.strip()]
                if len(ps)!=len(set(ps)):self.fail("関数の引数名が重複しています")
                body,i,_=self.take(lines,i,{"おわり"});self.functions[m.group(1)]=(ps,body);continue
            m=re.fullmatch(r"(\w+)\[(.+)\]\s*=\s*(.+)",s)
            if m:
                self.expression(m.group(1))[self.expression(m.group(2))]=self.expression(m.group(3));continue
            m=re.fullmatch(r"(\w+)\s*=\s*(.+)",s)
            if m:self.env[m.group(1)]=self.expression(m.group(2));continue
            if re.fullmatch(r"[^\s(]+\s*\(.*\)",s):self.expression(s);continue
            self.fail(f"この命令はまだ使えません: {s}")

def main(argv=None):
    argv=sys.argv[1:] if argv is None else argv
    if len(argv)!=1:
        print("使い方: python yaccho.py sample.yaccho",file=sys.stderr);return 2
    try:Interpreter().run_file(argv[0]);return 0
    except (_Break,_Continue,_Return):print("YACCHOエラー: 制御命令を使える場所ではありません",file=sys.stderr);return 1
    except (YacchoError,ZeroDivisionError,TypeError,ValueError,IndexError,KeyError) as e:
        print(f"YACCHOエラー: {e}",file=sys.stderr);return 1
if __name__=="__main__":raise SystemExit(main())
