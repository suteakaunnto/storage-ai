# YACCHO v0.3
日本語を中心に書ける学習用インタプリタの試作版です。Python 3.10以降が必要です。

## Windowsでの実行
展開したフォルダーでコマンドプロンプトを開き、次を実行します。

```bat
python yaccho.py sample.yaccho
python yaccho.py test_suite.yaccho
python test_yaccho.py
```

## v0.3の機能
- 変数、文字列、整数、小数、真偽値、なし
- 四則演算、比較演算、and / or / not
- リスト、タプル、辞書、添字アクセスと代入
- もし / そうでなければ
- N回くりかえす、条件 ... のあいだくりかえす
- それぞれ ... in ... くりかえす
- ぬける、つぎへ
- 関数、返す
- 表示、長さ、追加、削除、範囲、型

## テスト
test_suite.yaccho はYACCHO自身で動かす自己テスト、test_yaccho.py はPython標準unittestによる詳細テストです。

## 制限
学習・実験用の試作です。クラス、モジュール、ファイル入出力、例外処理、文字列補間などは未実装です。関数内の変数はローカルです。式は許可したAST構文だけを評価します。
