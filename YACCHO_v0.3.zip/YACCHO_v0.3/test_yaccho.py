import unittest
from yaccho import Interpreter, YacchoError

class Tests(unittest.TestCase):
    def run_y(self,s,max_loop=100000):
        out=[];vm=Interpreter(output=lambda *a:out.append(" ".join(map(str,a))),max_loop=max_loop)
        vm.run_text(s);return out,vm
    def test_arithmetic(self): self.assertEqual(self.run_y("表示(2 + 3 * 4)\n表示((2 + 3) * 4)")[0],["14","20"])
    def test_logic(self): self.assertEqual(self.run_y("表示(3 < 5 and 5 < 8)\n表示(3 > 5 or 5 == 5)\n表示(not False)")[0],["True","True","True"])
    def test_compare_membership(self): self.assertEqual(self.run_y("表示(1 < 2 < 3)\n表示(2 in [1,2,3])\n表示(4 not in [1,2,3])")[0],["True","True","True"])
    def test_collections(self): self.assertEqual(self.run_y('a=[1,2]\nt=(7,8)\nd={"x":9}\n表示(a[1],t[0],d["x"])')[0],["2 7 9"])
    def test_mutation(self): self.assertEqual(self.run_y("a=[1,2]\n追加(a,3)\n表示(長さ(a))\n表示(削除(a,0))\n表示(a)")[0],["3","1","[2, 3]"])
    def test_range_type(self): self.assertEqual(self.run_y('表示(範囲(3))\n表示(範囲(2,7,2))\n表示(型("abc"))\n表示(型([1]))')[0],["[0, 1, 2]","[2, 4, 6]","文字列","リスト"])
    def test_if_else(self): self.assertEqual(self.run_y('x=4\nもし x > 3 なら\n表示("yes")\nそうでなければ\n表示("no")\nおわり')[0],["yes"])
    def test_repeat(self): self.assertEqual(self.run_y("x=0\n4回くりかえす\nx=x+1\nおわり\n表示(x)")[0],["4"])
    def test_while_break_continue(self):
        s="""i=0
s=0
条件 i < 8 のあいだくりかえす
i=i+1
もし i == 2 なら
つぎへ
おわり
もし i == 6 なら
ぬける
おわり
s=s+i
おわり
表示(i,s)"""
        self.assertEqual(self.run_y(s)[0],["6 13"])
    def test_foreach(self): self.assertEqual(self.run_y("s=0\nそれぞれ x in 範囲(1,5) くりかえす\ns=s+x\nおわり\n表示(s)")[0],["10"])
    def test_function_scope_return(self):
        s="""outside=100
関数 add(a,b)
inside=a+b
返す inside
おわり
表示(add(2,5))
表示(outside)"""
        out,vm=self.run_y(s);self.assertEqual(out,["7","100"]);self.assertNotIn("inside",vm.env)
    def test_nested(self): self.assertEqual(self.run_y("x=0\n2回くりかえす\nもし True なら\nx=x+1\nおわり\nおわり\n表示(x)")[0],["2"])
    def test_index_assign(self): self.assertEqual(self.run_y("a=[1,2]\na[1]=9\n表示(a)")[0],["[1, 9]"])
    def test_line_error(self):
        with self.assertRaisesRegex(YacchoError,"2行目"):self.run_y("x=1\n表示(missing)")
    def test_loop_limit(self):
        with self.assertRaisesRegex(YacchoError,"上限"):self.run_y("x=0\n条件 x < 10 のあいだくりかえす\nx=x+1\nおわり",3)
    def test_arity(self):
        with self.assertRaisesRegex(YacchoError,"引数の数"):self.run_y("関数 f(a)\n返す a\nおわり\nf()")
    def test_no_attribute(self):
        with self.assertRaises(YacchoError):self.run_y('表示("x".upper())')
    def test_no_import(self):
        with self.assertRaises(YacchoError):self.run_y("import os")

if __name__=="__main__":unittest.main(verbosity=2)
